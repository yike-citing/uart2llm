# SPDX-FileCopyrightText: 2024-2025 Fredrik Ahlberg, Angus Gratton,
# Espressif Systems (Shanghai) CO LTD, other contributors as noted.
#
# SPDX-License-Identifier: GPL-2.0-or-later

import struct
from time import sleep

from ..loader import ESPLoader, StubMixin
from ..logger import log
from ..util import FatalError, NotSupportedError
from .esp32 import ESP32ROM


class ESP32P4ROM(ESP32ROM):
    CHIP_NAME = "ESP32-P4"
    IMAGE_CHIP_ID = 18

    IROM_MAP_START = 0x40000000
    IROM_MAP_END = 0x4C000000
    DROM_MAP_START = 0x40000000
    DROM_MAP_END = 0x4C000000

    BOOTLOADER_FLASH_OFFSET = 0x2000  # First 2 sectors are reserved for FE purposes

    UART_DATE_REG_ADDR = 0x500CA000 + 0x8C

    EFUSE_BASE = 0x5012D000
    EFUSE_BLOCK1_ADDR = EFUSE_BASE + 0x044
    MAC_EFUSE_REG = EFUSE_BASE + 0x044

    SPI_REG_BASE = 0x5008D000  # SPIMEM1
    SPI_USR_OFFS = 0x18
    SPI_USR1_OFFS = 0x1C
    SPI_USR2_OFFS = 0x20
    SPI_MOSI_DLEN_OFFS = 0x24
    SPI_MISO_DLEN_OFFS = 0x28
    SPI_W0_OFFS = 0x58

    SPI_ADDR_REG_MSB = False

    USES_MAGIC_VALUE = False

    EFUSE_RD_REG_BASE = EFUSE_BASE + 0x030  # BLOCK0 read base address

    EFUSE_FORCE_USE_KEY_MANAGER_KEY_REG = EFUSE_BASE + 0x34
    EFUSE_FORCE_USE_KEY_MANAGER_KEY_SHIFT = 9
    FORCE_USE_KEY_MANAGER_VAL_XTS_AES_KEY = 2

    EFUSE_PURPOSE_KEY0_REG = EFUSE_BASE + 0x34
    EFUSE_PURPOSE_KEY0_SHIFT = 24
    EFUSE_PURPOSE_KEY1_REG = EFUSE_BASE + 0x34
    EFUSE_PURPOSE_KEY1_SHIFT = 28
    EFUSE_PURPOSE_KEY2_REG = EFUSE_BASE + 0x38
    EFUSE_PURPOSE_KEY2_SHIFT = 0
    EFUSE_PURPOSE_KEY3_REG = EFUSE_BASE + 0x38
    EFUSE_PURPOSE_KEY3_SHIFT = 4
    EFUSE_PURPOSE_KEY4_REG = EFUSE_BASE + 0x38
    EFUSE_PURPOSE_KEY4_SHIFT = 8
    EFUSE_PURPOSE_KEY5_REG = EFUSE_BASE + 0x38
    EFUSE_PURPOSE_KEY5_SHIFT = 12

    EFUSE_DIS_DOWNLOAD_MANUAL_ENCRYPT_REG = EFUSE_RD_REG_BASE
    EFUSE_DIS_DOWNLOAD_MANUAL_ENCRYPT = 1 << 20

    EFUSE_RD_REPEAT_DATA1_REG = EFUSE_BASE + 0x034
    EFUSE_SPI_BOOT_CRYPT_CNT_REG = EFUSE_RD_REPEAT_DATA1_REG
    EFUSE_SPI_BOOT_CRYPT_CNT_MASK = 0x7 << 18
    EFUSE_DOWNLOAD_MODE_XPD_ON_MASK = 0x1 << 16

    EFUSE_SECURE_BOOT_EN_REG = EFUSE_BASE + 0x038
    EFUSE_SECURE_BOOT_EN_MASK = 1 << 20

    PURPOSE_VAL_XTS_AES256_KEY_1 = 2
    PURPOSE_VAL_XTS_AES256_KEY_2 = 3
    PURPOSE_VAL_XTS_AES128_KEY = 4

    USB_RAM_BLOCK = 0x800  # Max block size USB-OTG is used

    GPIO_STRAP_REG = 0x500E0038
    GPIO_STRAP_SPI_BOOT_MASK = 0x8  # Not download mode
    RTC_CNTL_OPTION1_REG = 0x50110008
    RTC_CNTL_FORCE_DOWNLOAD_BOOT_MASK = 0x4  # Is download mode forced over USB?

    FLASH_ENCRYPTED_WRITE_ALIGN = 16

    # Flash power-on related registers and bits needed for ECO6
    DR_REG_LPAON_BASE = 0x50110000
    DR_REG_PMU_BASE = DR_REG_LPAON_BASE + 0x5000
    DR_REG_LP_SYS_BASE = DR_REG_LPAON_BASE + 0x0
    LP_SYSTEM_REG_ANA_XPD_PAD_GROUP_REG = DR_REG_LP_SYS_BASE + 0x10C
    PMU_EXT_LDO_P0_0P1A_ANA_REG = DR_REG_PMU_BASE + 0x1BC
    PMU_ANA_0P1A_EN_CUR_LIM_0 = 1 << 27
    PMU_EXT_LDO_P0_0P1A_REG = DR_REG_PMU_BASE + 0x1B8
    PMU_0P1A_TARGET0_0 = 0xFF << 23
    PMU_0P1A_FORCE_TIEH_SEL_0 = 1 << 7
    PMU_DATE_REG = DR_REG_PMU_BASE + 0x3FC
    # Flash “force on” (XPD) control bits inside PMU_DATE_REG
    PMU_DATE_FLASH_FORCE_ON = 0x3

    MEMORY_MAP = [
        [0x00000000, 0x00010000, "PADDING"],
        [0x40000000, 0x4C000000, "DROM"],
        [0x4FF00000, 0x4FFA0000, "DRAM"],
        [0x4FF00000, 0x4FFA0000, "BYTE_ACCESSIBLE"],
        [0x4FC00000, 0x4FC20000, "DROM_MASK"],
        [0x4FC00000, 0x4FC20000, "IROM_MASK"],
        [0x40000000, 0x4C000000, "IROM"],
        [0x4FF00000, 0x4FFA0000, "IRAM"],
        [0x50108000, 0x50110000, "RTC_IRAM"],
        [0x50108000, 0x50110000, "RTC_DRAM"],
        [0x600FE000, 0x60100000, "MEM_INTERNAL2"],
    ]

    UF2_FAMILY_ID = 0x3D308E94

    KEY_PURPOSES: dict[int, str] = {
        0: "USER/EMPTY",
        1: "ECDSA_KEY",
        2: "XTS_AES_256_KEY_1",
        3: "XTS_AES_256_KEY_2",
        4: "XTS_AES_128_KEY",
        5: "HMAC_DOWN_ALL",
        6: "HMAC_DOWN_JTAG",
        7: "HMAC_DOWN_DIGITAL_SIGNATURE",
        8: "HMAC_UP",
        9: "SECURE_BOOT_DIGEST0",
        10: "SECURE_BOOT_DIGEST1",
        11: "SECURE_BOOT_DIGEST2",
        12: "KM_INIT_KEY",
    }

    DR_REG_LP_WDT_BASE = 0x50116000
    RTC_CNTL_WDTCONFIG0_REG = DR_REG_LP_WDT_BASE + 0x0  # LP_WDT_CONFIG0_REG
    RTC_CNTL_WDTCONFIG1_REG = DR_REG_LP_WDT_BASE + 0x0004  # LP_WDT_CONFIG1_REG
    RTC_CNTL_WDTWPROTECT_REG = DR_REG_LP_WDT_BASE + 0x0018  # LP_WDT_WPROTECT_REG
    RTC_CNTL_WDT_WKEY = 0x50D83AA1

    RTC_CNTL_SWD_CONF_REG = DR_REG_LP_WDT_BASE + 0x001C  # RTC_WDT_SWD_CONFIG_REG
    RTC_CNTL_SWD_AUTO_FEED_EN = 1 << 18
    RTC_CNTL_SWD_WPROTECT_REG = DR_REG_LP_WDT_BASE + 0x0020  # RTC_WDT_SWD_WPROTECT_REG
    RTC_CNTL_SWD_WKEY = 0x50D83AA1  # RTC_WDT_SWD_WKEY, same as WDT key in this case

    def get_pkg_version(self):
        num_word = 2
        return (self.read_reg(self.EFUSE_BLOCK1_ADDR + (4 * num_word)) >> 20) & 0x07

    def get_minor_chip_version(self):
        num_word = 2
        return (self.read_reg(self.EFUSE_BLOCK1_ADDR + (4 * num_word)) >> 0) & 0x0F

    def get_major_chip_version(self):
        num_word = 2
        word = self.read_reg(self.EFUSE_BLOCK1_ADDR + (4 * num_word))
        return (((word >> 23) & 1) << 2) | ((word >> 4) & 0x03)

    def get_chip_description(self):
        chip_name = {
            0: "ESP32-P4",
        }.get(self.get_pkg_version(), "Unknown ESP32-P4")
        major_rev = self.get_major_chip_version()
        minor_rev = self.get_minor_chip_version()
        return f"{chip_name} (revision v{major_rev}.{minor_rev})"

    def get_chip_features(self):
        return ["Dual Core + LP Core", "400MHz"]

    def get_crystal_freq(self):
        # ESP32P4 XTAL is fixed to 40MHz
        return 40

    def get_flash_voltage(self):
        raise NotSupportedError(self, "Reading flash voltage")

    def override_vddsdio(self, new_voltage):
        raise NotSupportedError(self, "Overriding VDDSDIO")

    def read_mac(self, mac_type="BASE_MAC"):
        """Read MAC from EFUSE region"""
        if mac_type != "BASE_MAC":
            return None
        mac0 = self.read_reg(self.MAC_EFUSE_REG)
        mac1 = self.read_reg(self.MAC_EFUSE_REG + 4)  # only bottom 16 bits are MAC
        bitstring = struct.pack(">II", mac1, mac0)[2:]
        return tuple(bitstring)

    def get_flash_crypt_config(self):
        return None  # doesn't exist on ESP32-P4

    def get_secure_boot_enabled(self):
        return (
            self.read_reg(self.EFUSE_SECURE_BOOT_EN_REG)
            & self.EFUSE_SECURE_BOOT_EN_MASK
        )

    def get_secure_boot_v1_enabled(self):
        # Secure Boot V1 is only supported on ESP32, not on ESP32-P4
        return False

    def get_key_block_purpose(self, key_block):
        if key_block < 0 or key_block > self.EFUSE_MAX_KEY:
            raise FatalError(
                f"Valid key block numbers must be in range 0-{self.EFUSE_MAX_KEY}"
            )

        reg, shift = [
            (self.EFUSE_PURPOSE_KEY0_REG, self.EFUSE_PURPOSE_KEY0_SHIFT),
            (self.EFUSE_PURPOSE_KEY1_REG, self.EFUSE_PURPOSE_KEY1_SHIFT),
            (self.EFUSE_PURPOSE_KEY2_REG, self.EFUSE_PURPOSE_KEY2_SHIFT),
            (self.EFUSE_PURPOSE_KEY3_REG, self.EFUSE_PURPOSE_KEY3_SHIFT),
            (self.EFUSE_PURPOSE_KEY4_REG, self.EFUSE_PURPOSE_KEY4_SHIFT),
            (self.EFUSE_PURPOSE_KEY5_REG, self.EFUSE_PURPOSE_KEY5_SHIFT),
        ][key_block]
        return (self.read_reg(reg) >> shift) & 0xF

    def uses_key_manager_for_flash_encryption(self):
        return bool(
            (
                self.read_reg(self.EFUSE_FORCE_USE_KEY_MANAGER_KEY_REG)
                >> self.EFUSE_FORCE_USE_KEY_MANAGER_KEY_SHIFT
            )
            & self.FORCE_USE_KEY_MANAGER_VAL_XTS_AES_KEY
        )

    def is_flash_encryption_key_valid(self):
        # Need to see either an AES-128 key or two AES-256 keys
        purposes = [
            self.get_key_block_purpose(b) for b in range(self.EFUSE_MAX_KEY + 1)
        ]

        if any(p == self.PURPOSE_VAL_XTS_AES128_KEY for p in purposes):
            return True

        if any(p == self.PURPOSE_VAL_XTS_AES256_KEY_1 for p in purposes) and any(
            p == self.PURPOSE_VAL_XTS_AES256_KEY_2 for p in purposes
        ):
            return True

        return self.uses_key_manager_for_flash_encryption()

    def change_baud(self, baud):
        ESPLoader.change_baud(self, baud)

    def _post_connect(self):
        if self.uses_usb_otg():
            self.ESP_RAM_BLOCK = self.USB_RAM_BLOCK
        if not self.secure_download_mode:
            if not self.sync_stub_detected:  # Don't run if stub is reused
                self.disable_watchdogs()
            self.power_on_flash()  # Needs to be powered on before attach_flash()

    def disable_watchdogs(self):
        # When USB-JTAG/Serial is used, the RTC WDT and SWD watchdog are not reset
        # and can then reset the board during flashing. Disable them.
        if self.uses_usb_jtag_serial():
            # Disable RTC WDT
            self.write_reg(self.RTC_CNTL_WDTWPROTECT_REG, self.RTC_CNTL_SWD_WKEY)
            self.write_reg(self.RTC_CNTL_WDTCONFIG0_REG, 0)
            self.write_reg(self.RTC_CNTL_WDTWPROTECT_REG, 0)

            # Automatically feed SWD
            self.write_reg(self.RTC_CNTL_SWD_WPROTECT_REG, self.RTC_CNTL_SWD_WKEY)
            self.write_reg(
                self.RTC_CNTL_SWD_CONF_REG,
                self.read_reg(self.RTC_CNTL_SWD_CONF_REG)
                | self.RTC_CNTL_SWD_AUTO_FEED_EN,
            )
            self.write_reg(self.RTC_CNTL_SWD_WPROTECT_REG, 0)

    def check_spi_connection(self, spi_connection):
        if not set(spi_connection).issubset(set(range(0, 55))):
            raise FatalError("SPI Pin numbers must be in the range 0-54.")
        if any([v for v in spi_connection if v in [24, 25]]):
            log.warn(
                "GPIO pins 24 and 25 are used by USB-Serial/JTAG, "
                "consider using other pins for SPI flash connection."
            )

    def watchdog_reset(self):
        log.print("Hard resetting with a watchdog...")
        self.write_reg(self.RTC_CNTL_WDTWPROTECT_REG, self.RTC_CNTL_WDT_WKEY)  # unlock
        self.write_reg(self.RTC_CNTL_WDTCONFIG1_REG, 2000)  # set WDT timeout
        self.write_reg(
            self.RTC_CNTL_WDTCONFIG0_REG, (1 << 31) | (5 << 28) | (1 << 8) | 2
        )  # enable WDT
        self.write_reg(self.RTC_CNTL_WDTWPROTECT_REG, 0)  # lock
        sleep(0.5)  # wait for reset to take effect

    def hard_reset(self):
        if self.uses_usb_otg():
            self.watchdog_reset()
        else:
            ESPLoader.hard_reset(self)

    def power_on_flash(self):
        """Power on the flash chip by setting the appropriate regs."""
        if self.secure_download_mode:
            raise NotSupportedError(self, "Powering on flash in secure download mode")

        revision = self.get_chip_revision()
        # Flash defaults off on ECO6/ECO7 after the 1.8 V → 3.3 V default change
        # (protects 1.8 V parts, board voltage must be set in eFuse). Other silicon
        # revisions do not need this sequence.
        if revision not in [301, 302]:
            return

        # On ECO7, also skip when DOWNLOAD_MODE_XPD_ON is programmed: ROM already
        # asserts flash XPD in download mode, so esptool must not run this path.
        if revision == 302 and (
            self.read_reg(self.EFUSE_RD_REPEAT_DATA1_REG)
            & self.EFUSE_DOWNLOAD_MODE_XPD_ON_MASK
        ):
            # ECO7 ROM bug: on a cold power-on, ROM can assert flash XPD (force
            # the flash supply/pads on) and the first download session works.
            # A subsequent entry into ROM download mode over USB–UART reset leaves
            # the flash already powered, but ROM still runs the same “turn flash XPD on”
            # path. That path is not safe to run twice while flash is already on,
            # so the second attach/download can fail.
            #
            # Clear the flash force-on bits in PMU_DATE_REG so the “flash force on”
            # state from the power-up sequence is released before the loader
            # proceeds to SPI flash attach. Leave the rest of the register intact.
            date = self.read_reg(self.PMU_DATE_REG)
            if (date & self.PMU_DATE_FLASH_FORCE_ON) == self.PMU_DATE_FLASH_FORCE_ON:
                self.write_reg(self.PMU_DATE_REG, date & ~self.PMU_DATE_FLASH_FORCE_ON)
            return

        # Power up pad group
        self.write_reg(self.LP_SYSTEM_REG_ANA_XPD_PAD_GROUP_REG, 1)
        sleep(0.01)
        # Flash power up sequence
        self.write_reg(
            self.PMU_EXT_LDO_P0_0P1A_ANA_REG,
            self.read_reg(self.PMU_EXT_LDO_P0_0P1A_ANA_REG)
            | self.PMU_ANA_0P1A_EN_CUR_LIM_0,
        )
        self.write_reg(
            self.PMU_EXT_LDO_P0_0P1A_REG,
            self.read_reg(self.PMU_EXT_LDO_P0_0P1A_REG)
            | self.PMU_0P1A_FORCE_TIEH_SEL_0,
        )
        self.write_reg(
            self.PMU_DATE_REG,
            self.read_reg(self.PMU_DATE_REG) | self.PMU_DATE_FLASH_FORCE_ON,
        )
        sleep(0.00005)
        self.write_reg(
            self.PMU_EXT_LDO_P0_0P1A_ANA_REG,
            self.read_reg(self.PMU_EXT_LDO_P0_0P1A_ANA_REG)
            & ~self.PMU_ANA_0P1A_EN_CUR_LIM_0,
        )
        self.write_reg(
            self.PMU_EXT_LDO_P0_0P1A_REG,
            self.read_reg(self.PMU_EXT_LDO_P0_0P1A_REG) & ~self.PMU_0P1A_TARGET0_0,
        )
        # Update eFuse voltage to PMU
        self.write_reg(
            self.PMU_EXT_LDO_P0_0P1A_REG,
            self.read_reg(self.PMU_EXT_LDO_P0_0P1A_REG) | 0x80,
        )
        self.write_reg(
            self.PMU_EXT_LDO_P0_0P1A_REG,
            self.read_reg(self.PMU_EXT_LDO_P0_0P1A_REG)
            & ~self.PMU_0P1A_FORCE_TIEH_SEL_0,
        )
        sleep(0.0018)


class ESP32P4StubLoader(StubMixin, ESP32P4ROM):
    """Stub loader for ESP32-P4, runs on top of ROM."""

    def __init__(self, rom_loader):
        super().__init__(rom_loader)  # Initialize the mixin
        if rom_loader.uses_usb_otg():
            self.ESP_RAM_BLOCK = self.USB_RAM_BLOCK
            self.FLASH_WRITE_SIZE = self.USB_RAM_BLOCK

    def stub_json_name(self):
        if self.get_chip_revision() < 300:
            return "esp32p4-rev1.json"
        return "esp32p4.json"


ESP32P4ROM.STUB_CLASS = ESP32P4StubLoader
